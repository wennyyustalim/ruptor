# Cleaned Data > 2022-12-24 1:08am
https://universe.roboflow.com/cleaned-augmented-grayscale-for-training/cleaned-data-bbak9

Provided by a Roboflow user
License: CC BY 4.0

